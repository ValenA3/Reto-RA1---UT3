# Parte 3 — (Definición pendiente)
Esta carpeta queda reservada para la Parte 3 del Reto 03.
