# Parte 1 — Actividades A y B (único archivo)
*(Rellena a partir de `plantilla_parte1.md`)*

## Actividad A — Investigación de Fuentes de Alimentación
[Completar tablas por tienda y la tabla resumen global.]

## Actividad B — Refrigeración para la MISMA CPU (Líquida vs Pasiva)
[Completar tabla comparativa, análisis por perfil y conclusión.]
