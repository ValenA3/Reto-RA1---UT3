# Parte 2 — (Definición pendiente)
Esta carpeta queda reservada para la Parte 2 del Reto 03.
