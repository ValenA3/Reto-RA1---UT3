# Reto 03 — Elementos internos de un sistema informático (UT2 · RA1)

**Alumno/a:** Apellido1 Apellido2, Nombre  
**Grupo:**  
**Fecha:**  
**Repositorio:** (URL opcional)
