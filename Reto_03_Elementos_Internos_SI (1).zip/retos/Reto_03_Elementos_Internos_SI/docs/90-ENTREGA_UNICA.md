# Reto 03 — Elementos internos de un sistema informático (UT2 · RA1)

> **Instrucciones:** Copia aquí el contenido final de cada parte. Para ahora, consolida **solo la Parte 1 (A y B)**.

## Parte 1 — Actividades A y B
(Pegar desde `10-parte1_fuentes_y_refrigeracion/tu_parte1.md`)

---
## Parte 2 — (TBD)
(Se añadirá más adelante)

---
## Parte 3 — (TBD)
(Se añadirá más adelante)
